package com.springrest.springrest.services;

public interface MyService {
	public String checkServiceCode(String code);
}
