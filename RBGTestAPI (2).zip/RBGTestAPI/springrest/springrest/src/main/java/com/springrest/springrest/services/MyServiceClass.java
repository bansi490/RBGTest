package com.springrest.springrest.services;

import com.springrest.springrest.services.MyService;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.stereotype.Service;


import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

@Service
public class MyServiceClass implements MyService {
	public String checkServiceCode(String code)
	{
		String path="C:\\Users\\Bansi.Joshi\\Downloads\\API\\springrest\\springrest\\src\\main\\java\\com\\springrest\\springrest\\services\\pav.json";
		
		InputStream fis=null;
		try {
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		JsonReader jsonReader = Json.createReader(fis);
		
		
		JsonArray jsonArray = jsonReader.readArray();
		
		
		jsonReader.close();
		try {
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String fin="";
		boolean flag=false;
		for(int i=0;i<jsonArray.size();i++)
		{
			JsonObject objects = jsonArray.getJsonObject(i);
			if(objects.getString("serviceCode").equals(code))
			{
				String serviceCode = objects.getString("serviceCode");
				String description = objects.getString("description");
				boolean metadata = objects.getBoolean("metadata");
				String type = objects.getString("type");
				fin=serviceCode+" "+description+" "+metadata+" "+type;
				flag=true;
				return fin;
			}
		}
		
		if(!flag)
		{
			fin="404, Not Found";
		}
		
		return fin;
	}
}
