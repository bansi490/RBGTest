package com.springrest.springrest.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.services.MyService;

@Controller
//@RestController
public class MyController {

	@Autowired
	private MyService myService;
	
	@GetMapping("/home")
	public String home()
	{
		return "Home";
	}
	
//	@GetMapping("/courses")
//	public String giveAll()
//	{
//		return "all";
//	}
	
	//@GetMapping("/services")
	@RequestMapping(value="services", method = RequestMethod.GET)
	public  String getResponse(@RequestParam("ServiceCode") Optional<String> ServiceCode, Model m)
	{
		if(ServiceCode.isPresent()) {
			String ss = this.myService.checkServiceCode(ServiceCode.get());
			
			if(!ss.equals("false")) 
			{
				String sp[]=ss.split(" ");
				String des="";
				for(int i=1;i<sp.length-2;i++)
					des+=sp[i]+" ";
				m.addAttribute("ServiceCode",ServiceCode.get());
				m.addAttribute("description",des);
				m.addAttribute("metadata",sp[3]);
				m.addAttribute("type",sp[4]);
				
				return "page";
			
			}
			
			else {
				return "error";
			}
		}
	
	else
	{
		return "all";
	}
}
	
	
}
